import React, { useState } from 'react';

interface ImageComparisonCardProps {
  title: string;
  beforeImage: string;
  afterImage: string;
  beforeLabel?: string;
  afterLabel?: string;
}

const ImageComparisonCard: React.FC<ImageComparisonCardProps> = ({
  title,
  beforeImage,
  afterImage,
  beforeLabel = 'Before',
  afterLabel = 'After'
}) => {
  const [sliderPosition, setSliderPosition] = useState(50);
  
  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSliderPosition(Number(e.target.value));
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden">
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-800 mb-2">{title}</h3>
        
        <div className="relative h-64 overflow-hidden">
          {/* Before Image (Full width) */}
          <div className="absolute inset-0">
            <img 
              src={beforeImage} 
              alt={beforeLabel}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded">
              {beforeLabel}
            </div>
          </div>
          
          {/* After Image (Partial width based on slider) */}
          <div 
            className="absolute inset-0 overflow-hidden" 
            style={{ width: `${sliderPosition}%` }}
          >
            <img 
              src={afterImage} 
              alt={afterLabel}
              className="absolute top-0 left-0 w-full h-full object-cover"
            />
            <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white text-xs px-2 py-1 rounded">
              {afterLabel}
            </div>
          </div>
          
          {/* Slider Line */}
          <div 
            className="absolute inset-y-0 w-0.5 bg-white cursor-ew-resize"
            style={{ left: `${sliderPosition}%` }}
          >
            <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-6 h-6 bg-white rounded-full border-2 border-gray-300 flex items-center justify-center">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 5L3 10L8 15" stroke="#4F46E5" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M16 5L21 10L16 15" stroke="#4F46E5" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>
        </div>
        
        <input
          type="range"
          min="0"
          max="100"
          value={sliderPosition}
          onChange={handleSliderChange}
          className="w-full mt-4 accent-indigo-600"
        />
      </div>
    </div>
  );
};

export default ImageComparisonCard;