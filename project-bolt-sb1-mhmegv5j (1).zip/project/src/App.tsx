import React, { useState } from 'react';
import { Brain, Zap, ImagePlus, Microscope, ChevronRight, Github } from 'lucide-react';
import Header from './components/Header';
import Footer from './components/Footer';
import ImageComparisonCard from './components/ImageComparisonCard';
import InfoCard from './components/InfoCard';
import ImageUpload from './components/ImageUpload';
import { processImage, calculateMetrics } from './services/imageProcessing';
import { ProcessingType, ImageMetrics } from './types';

function App() {
  const [activeTab, setActiveTab] = useState('demo');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [processing, setProcessing] = useState(false);
  const [processedImageUrl, setProcessedImageUrl] = useState<string | null>(null);
  const [originalImageUrl, setOriginalImageUrl] = useState<string | null>(null);
  const [processingType, setProcessingType] = useState<ProcessingType>('super-resolution');
  const [metrics, setMetrics] = useState<ImageMetrics | null>(null);

  const handleImageSelect = (file: File) => {
    setSelectedImage(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setOriginalImageUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleProcessImage = async () => {
    if (!selectedImage || !originalImageUrl) return;
    
    setProcessing(true);
    try {
      const processed = await processImage(selectedImage, processingType);
      setProcessedImageUrl(processed);
      
      const newMetrics = calculateMetrics(originalImageUrl, processed);
      setMetrics(newMetrics);
    } catch (error) {
      console.error('Error processing image:', error);
    } finally {
      setProcessing(false);
    }
  };

  const handleDownload = () => {
    if (processedImageUrl) {
      const link = document.createElement('a');
      link.href = processedImageUrl;
      link.download = `processed-${selectedImage?.name || 'image'}`;
      link.click();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 flex flex-col">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <section className="mb-16 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
              Medical Image Enhancement with GANs
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Exploring the application of Generative Adversarial Networks in medical imaging
              for super-resolution and image inpainting.
            </p>
            <div className="flex justify-center gap-4">
              <button 
                className="px-6 py-3 bg-indigo-600 text-white rounded-lg flex items-center gap-2 hover:bg-indigo-700 transition-colors"
                onClick={() => setActiveTab('demo')}
              >
                Try Demo <ChevronRight size={18} />
              </button>
              <a 
                href="https://github.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="px-6 py-3 bg-gray-200 text-gray-800 rounded-lg flex items-center gap-2 hover:bg-gray-300 transition-colors"
              >
                <Github size={18} /> View on GitHub
              </a>
            </div>
          </div>
        </section>

        <div className="flex justify-center mb-8">
          <nav className="flex space-x-1 rounded-lg bg-gray-200 p-1">
            {[
              { id: 'overview', label: 'Overview', icon: <Brain size={18} /> },
              { id: 'gans', label: 'GANs', icon: <Zap size={18} /> },
              { id: 'inpainting', label: 'Image Inpainting', icon: <ImagePlus size={18} /> },
              { id: 'demo', label: 'Interactive Demo', icon: <Microscope size={18} /> },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center px-4 py-2 text-sm font-medium rounded-md ${
                  activeTab === tab.id
                    ? 'bg-white text-indigo-700 shadow'
                    : 'text-gray-700 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="max-w-6xl mx-auto">
          {activeTab === 'overview' && (
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-gray-800 mb-6">Medical Imaging Enhancement</h2>
              
              <p className="text-lg text-gray-700">
                Medical imaging plays a crucial role in diagnosis and treatment planning. However, limitations in 
                imaging technology, patient movement, or hardware constraints can result in images with artifacts, 
                noise, or low resolution. Advanced deep learning techniques like Generative Adversarial Networks (GANs) 
                can significantly improve image quality, potentially leading to more accurate diagnoses.
              </p>
              
              <div className="grid md:grid-cols-2 gap-8 mt-8">
                <InfoCard 
                  title="Super-Resolution" 
                  icon={<Zap className="text-indigo-600\" size={24} />}
                  description="Enhancing the resolution of medical images to reveal fine details that might be crucial for diagnosis."
                />
                <InfoCard 
                  title="Image Inpainting" 
                  icon={<ImagePlus className="text-indigo-600\" size={24} />}
                  description="Filling in missing or corrupted parts of medical scans using contextual information from surrounding areas."
                />
              </div>
              
              <div className="bg-white rounded-xl shadow-md overflow-hidden mt-8">
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">Key Benefits in Medical Imaging</h3>
                  <ul className="space-y-2 text-gray-700">
                    <li className="flex items-start">
                      <span className="text-indigo-600 mr-2">•</span>
                      <span>Improved diagnostic accuracy through enhanced image clarity</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 mr-2">•</span>
                      <span>Reduction in the need for repeat scans, lowering radiation exposure</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 mr-2">•</span>
                      <span>Recovery of details in low-quality or partially corrupted scans</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 mr-2">•</span>
                      <span>Potential for earlier detection of subtle pathological changes</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'gans' && (
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-gray-800 mb-6">Generative Adversarial Networks</h2>
              
              <p className="text-lg text-gray-700">
                Generative Adversarial Networks (GANs) represent a revolutionary approach in deep learning, 
                consisting of two neural networks—a generator and a discriminator—that compete against each 
                other in a minimax game. This architecture has proven particularly effective for image-related tasks.
              </p>
              
              <div className="bg-white rounded-xl shadow-md overflow-hidden mt-8">
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">How GANs Work</h3>
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                        <span className="text-indigo-600 font-semibold">1</span>
                      </div>
                      <div className="ml-4">
                        <h4 className="text-md font-medium text-gray-800">Generator Network</h4>
                        <p className="text-gray-600">Creates synthetic images that aim to be indistinguishable from real ones</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                        <span className="text-indigo-600 font-semibold">2</span>
                      </div>
                      <div className="ml-4">
                        <h4 className="text-md font-medium text-gray-800">Discriminator Network</h4>
                        <p className="text-gray-600">Attempts to distinguish between real and generated images</p>
                      </div>
                    </div>
                    <div className="flex items-start">
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                        <span className="text-indigo-600 font-semibold">3</span>
                      </div>
                      <div className="ml-4">
                        <h4 className="text-md font-medium text-gray-800">Adversarial Training</h4>
                        <p className="text-gray-600">Both networks improve through competition, with the generator learning to create increasingly realistic images</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="grid md:grid-cols-2 gap-8 mt-8">
                <div className="bg-white rounded-xl shadow-md overflow-hidden">
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-gray-800 mb-4">GAN Architectures for Medical Imaging</h3>
                    <ul className="space-y-2 text-gray-700">
                      <li className="flex items-start">
                        <span className="text-indigo-600 mr-2">•</span>
                        <span><strong>Pix2Pix:</strong> Paired image-to-image translation</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-indigo-600 mr-2">•</span>
                        <span><strong>CycleGAN:</strong> Unpaired image translation</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-indigo-600 mr-2">•</span>
                        <span><strong>SRGAN:</strong> Super-resolution GAN</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-indigo-600 mr-2">•</span>
                        <span><strong>Context Encoders:</strong> For image inpainting</span>
                      </li>
                    </ul>
                  </div>
                </div>
                
                <div className="bg-white rounded-xl shadow-md overflow-hidden">
                  <div className="p-6">
                    <h3 className="text-xl font-semibold text-gray-800 mb-4">Challenges in Medical Applications</h3>
                    <ul className="space-y-2 text-gray-700">
                      <li className="flex items-start">
                        <span className="text-indigo-600 mr-2">•</span>
                        <span>Limited availability of large medical datasets</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-indigo-600 mr-2">•</span>
                        <span>Need for high precision in medical contexts</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-indigo-600 mr-2">•</span>
                        <span>Ethical considerations in synthetic data generation</span>
                      </li>
                      <li className="flex items-start">
                        <span className="text-indigo-600 mr-2">•</span>
                        <span>Validation and regulatory approval processes</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'inpainting' && (
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-gray-800 mb-6">Image Inpainting & Super-Resolution</h2>
              
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">Image Inpainting</h3>
                  <p className="text-gray-700 mb-4">
                    Image inpainting is the process of reconstructing missing or damaged parts of an image. 
                    In medical imaging, this technique can be used to:
                  </p>
                  <ul className="space-y-2 text-gray-700 mb-6">
                    <li className="flex items-start">
                      <span className="text-indigo-600 mr-2">•</span>
                      <span>Remove artifacts from MRI scans</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 mr-2">•</span>
                      <span>Fill in gaps in CT scans due to metal implants</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 mr-2">•</span>
                      <span>Correct motion artifacts in medical images</span>
                    </li>
                  </ul>
                  
                  <ImageComparisonCard 
                    title="MRI Artifact Removal"
                    beforeImage="https://images.pexels.com/photos/4226119/pexels-photo-4226119.jpeg?auto=compress&cs=tinysrgb&w=600"
                    afterImage="https://images.pexels.com/photos/4226264/pexels-photo-4226264.jpeg?auto=compress&cs=tinysrgb&w=600"
                    beforeLabel="With Artifacts"
                    afterLabel="After Inpainting"
                  />
                </div>
                
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">Super-Resolution</h3>
                  <p className="text-gray-700 mb-4">
                    Super-resolution techniques enhance the resolution and quality of low-resolution images. 
                    In medical contexts, this can:
                  </p>
                  <ul className="space-y-2 text-gray-700 mb-6">
                    <li className="flex items-start">
                      <span className="text-indigo-600 mr-2">•</span>
                      <span>Improve the visibility of small structures in radiographs</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 mr-2">•</span>
                      <span>Enhance details in ultrasound images</span>
                    </li>
                    <li className="flex items-start">
                      <span className="text-indigo-600 mr-2">•</span>
                      <span>Upgrade legacy medical imaging data to modern standards</span>
                    </li>
                  </ul>
                  
                  <ImageComparisonCard 
                    title="CT Scan Enhancement"
                    beforeImage="https://images.pexels.com/photos/8376164/pexels-photo-8376164.jpeg?auto=compress&cs=tinysrgb&w=600"
                    afterImage="https://images.pexels.com/photos/8376254/pexels-photo-8376254.jpeg?auto=compress&cs=tinysrgb&w=600"
                    beforeLabel="Low Resolution"
                    afterLabel="Enhanced Resolution"
                  />
                </div>
              </div>
              
              <div className="bg-white rounded-xl shadow-md overflow-hidden mt-8">
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-800 mb-4">Technical Approaches</h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2">GAN-Based Methods</h4>
                      <ul className="space-y-1 text-gray-700">
                        <li className="flex items-start">
                          <span className="text-indigo-600 mr-2">-</span>
                          <span>Context Encoders</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-indigo-600 mr-2">-</span>
                          <span>Partial Convolutions</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-indigo-600 mr-2">-</span>
                          <span>Gated Convolutions</span>
                        </li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800 mb-2">Super-Resolution Techniques</h4>
                      <ul className="space-y-1 text-gray-700">
                        <li className="flex items-start">
                          <span className="text-indigo-600 mr-2">-</span>
                          <span>SRGAN and ESRGAN</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-indigo-600 mr-2">-</span>
                          <span>Deep Back-Projection Networks</span>
                        </li>
                        <li className="flex items-start">
                          <span className="text-indigo-600 mr-2">-</span>
                          <span>Meta-SR for Arbitrary Scaling</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'demo' && (
            <div className="space-y-8">
              <h2 className="text-3xl font-bold text-gray-800 mb-6">Interactive Demo</h2>
              
              <div className="bg-white rounded-xl shadow-md overflow-hidden">
                <div className="p-6">
                  <p className="text-gray-700 mb-6">
                    Upload your medical image to see how our GAN-based enhancement techniques can improve image quality.
                  </p>
                  
                  <div className="grid md:grid-cols-2 gap-8">
                    <div className="space-y-4">
                      <h3 className="text-xl font-semibold text-gray-800">Upload Image</h3>
                      <ImageUpload onImageSelect={handleImageSelect} />
                      
                      <div className="space-y-4">
                        <h4 className="font-medium text-gray-800">Sample Images</h4>
                        <div className="grid grid-cols-3 gap-2">
                          {[1, 2, 3].map((i) => (
                            <button
                              key={i}
                              className="border rounded-md p-1 hover:border-indigo-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            >
                              <img
                                src={`https://images.pexels.com/photos/356040/pexels-photo-356040.jpeg?auto=compress&cs=tinysrgb&w=150`}
                                alt={`Sample ${i}`}
                                className="w-full h-auto rounded"
                              />
                            </button>
                          ))}
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-medium text-gray-800">Processing Options</h4>
                        <div className="space-y-2">
                          <label className="flex items-center">
                            <input
                              type="radio"
                              name="process-type"
                              value="super-resolution"
                              checked={processingType === 'super-resolution'}
                              onChange={(e) => setProcessingType('super-resolution')}
                              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500"
                            />
                            <span className="ml-2 text-gray-700">Super-Resolution</span>
                          </label>
                          <label className="flex items-center">
                            <input
                              type="radio"
                              name="process-type"
                              value="inpainting"
                              checked={processingType === 'inpainting'}
                              onChange={(e) => setProcessingType('inpainting')}
                              className="h-4 w-4 text-indigo-600 focus:ring-indigo-500"
                            />
                            <span className="ml-2 text-gray-700">Image Inpainting</span>
                          </label>
                        </div>
                      </div>
                      
                      <button
                        onClick={handleProcessImage}
                        disabled={!selectedImage || processing}
                        className={`w-full py-2 px-4 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 ${
                          !selectedImage || processing
                            ? 'bg-gray-300 cursor-not-allowed'
                            : 'bg-indigo-600 text-white hover:bg-indigo-700'
                        }`}
                      >
                        {processing ? 'Processing...' : 'Process Image'}
                      </button>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="text-xl font-semibold text-gray-800">Results</h3>
                      {processedImageUrl ? (
                        <ImageComparisonCard
                          title={processingType === 'super-resolution' ? 'Resolution Enhancement' : 'Image Inpainting'}
                          beforeImage={originalImageUrl!}
                          afterImage={processedImageUrl}
                          beforeLabel="Original"
                          afterLabel="Processed"
                        />
                      ) : (
                        <div className="border rounded-lg p-4 h-64 flex items-center justify-center bg-gray-50">
                          <p className="text-gray-500">Processed image will appear here</p>
                        </div>
                      )}
                      
                      <div className="space-y-2">
                        <h4 className="font-medium text-gray-800">Image Metrics</h4>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="bg-gray-50 p-3 rounded border">
                            <p className="text-xs text-gray-500">PSNR</p>
                            <p className="font-medium">{metrics?.psnr || '--'}</p>
                          </div>
                          <div className="bg-gray-50 p-3 rounded border">
                            <p className="text-xs text-gray-500">SSIM</p>
                            <p className="font-medium">{metrics?.ssim || '--'}</p>
                          </div>
                          <div className="bg-gray-50 p-3 rounded border">
                            <p className="text-xs text-gray-500">Resolution</p>
                            <p className="font-medium">{metrics?.resolution || '--'}</p>
                          </div>
                          <div className="bg-gray-50 p-3 rounded border">
                            <p className="text-xs text-gray-500">Processing Time</p>
                            <p className="font-medium">{metrics?.processingTime || '--'}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="pt-4">
                        <button 
                          onClick={handleDownload}
                          className="text-indigo-600 hover:text-indigo-800 text-sm font-medium flex items-center" 
                          disabled={!processedImageUrl || processing}
                        >
                          <span>Download Processed Image</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}

export default App;