export type ProcessingType = 'super-resolution' | 'inpainting';

export interface ImageMetrics {
  psnr: string;
  ssim: string;
  resolution: string;
  processingTime: string;
}